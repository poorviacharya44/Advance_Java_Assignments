package arraylist6_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentArrayList {
	public static void main(String[] args) {
		ArrayList<String> arr=new ArrayList<String>();
		
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of students :");
		n=sc.nextInt();
		System.out.println("Enter the student names :");
		
		for (int i=0; i<n; i++) {
			
			arr.add(sc.next());
			
		}
		System.out.println("Student list :"+ arr);
		
		for (String string : arr) {
			
			System.out.println("Enter the student name to search :");
			String str=sc.next();
			int position=Collections.binarySearch(arr,str);
			System.out.println("position of " +str+ " is :"+position);
			
		}
	}
}
