package splitstring5_2;

public class SplitMethod {
	public static void main(String[] args) {
		
		String txt= (" 23  +  45  -  (  343  /  12  ) ");
		String[] str=txt.split("\\\s");
		
		for(String str1:str){  
			System.out.println(str1); 
			//System.out.println(" ");
		}
	}
}
