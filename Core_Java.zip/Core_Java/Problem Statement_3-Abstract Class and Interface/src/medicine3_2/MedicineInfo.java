package medicine3_2;

public class MedicineInfo
{
public void displayLabel()
{
System.out.println("Company : Radha Pharmacy");
System.out.println("Address : Mangalore");
}
}
class Tablet extends MedicineInfo
{
public void displayLabel()
{
System.out.println("store in a cool dry place");
}
}
class Syrup extends MedicineInfo
{
public void displayLabel()
{
System.out.println("Consumption as directed by the physician");
}
}
class Ointment extends MedicineInfo
{
public void displayLabel()
{
System.out.println("for external use only");
}
}