package book1_3;

public class Book {
	private String booktitile;
	private double bookprice;
	public String getBooktitile() {
		return booktitile;
	}
	public void setBooktitile(String booktitile) {
		this.booktitile = booktitile;
	}
	public double getBookprice() {
		return bookprice;
	}
	public void setBookprice(double bookprice) {
		this.bookprice = bookprice;
	}

}